#include <iostream>
#include "TcpServer.hpp"
#include<signal.h>

int main(int argc, char *argv[])
{
    signal(SIGCHLD, SIG_IGN);  //自动回收子进程
    // ./tcp_server  8080
    if (argc > 2)
    {
        std::cout << "Usage ./server_tcp 8080" << std::endl;
        return 1;
    }

    uint16_t port = 8080;
    if (argc == 2)
    {
        port = ::atoi(argv[1]);
    }

    TcpServer server(port);

    server.InitServer();
    server.Start();

    return 0;
}
