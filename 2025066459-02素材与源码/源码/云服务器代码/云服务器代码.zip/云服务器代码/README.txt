使用环境是Centos7 + c++11 环境，使用make编译后，先执行./server_tcp ,在先后执行 ./qt ./esp即可（上述是用来测试）
如果配置好ESP芯片与QT软件端，直接运行./server_tcp即可